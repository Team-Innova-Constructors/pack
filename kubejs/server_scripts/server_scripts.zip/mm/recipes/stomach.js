MMEvents.createProcesses(event => {
    event.create("mm:my_process_recipe")
        .structureId("mm:stomach")
        .ticks(200)
        .input({
            type: "mm:input/consume",
            ingredient: {
                type: "mm:item",
                item: "minecraft:glass",
                count: 10
            },
        })
        .input({
            type: "mm:input/consume",
            ingredient: {
                type: "mm:fluid",
                fluid: "minecraft:water",
                amount: 1000
            }
        })
        .output({
            type: "mm:output/simple",
            ingredient: {
                type: "mm:fluid",
                fluid: "kubejs:volatile_lava",
                amount: 1000
            }
        })
        
})