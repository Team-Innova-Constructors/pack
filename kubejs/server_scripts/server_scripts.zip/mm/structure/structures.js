MMEvents.createStructures(event => {
    //过载能量注入器
    event.create("mm:overload_infuser")
        .controllerId("mm:overload_infuser")
        .name("过载能量注入器")
        .layout(a => {
            a.layer([
                "AAAAA",
                "ABBBA",
                "ABJBA",
                "ABBBA",
                "AAAAA"
            ]).layer([
                "AAAAA",
                "A   A",
                "A D A",
                "A   A",
                "AKGLA"
            ]).layer([
                "AAAAA",
                "A   A",
                "A H A",
                "A   A",
                "AGGGA"
            ]).layer([
                "AAAAA",
                "A   A",
                "A D A",
                "A   A",
                "AECFA"
            ]).layer([
                "AAAAA",
                "AIIIA",
                "AIJIA",
                "AIIIA",
                "AAAAA"
            ]).key("A", {
                block: "pneumaticcraft:smooth_plastic_brick_black"
            }).key("I", {
                block: "thermal:enderium_block"
            }).key("D", {
                block: "minecraft:end_rod"
            }).key("E", {
                tag: "mm:item_ports/tier3"
            }).key("F", {
                tag: "mm:item_ports/tier3"
            }).key("G", {
                block: "minecraft:tinted_glass"
            }).key("H", {
                block: "minecraft:heavy_weighted_pressure_plate"
            }).key("B", {
                block: "thermal:signalum_block"
            }).key("J", {
                tag: "mm:energy_ports/tier3"
            }).key("K", {
                tag: "mm:fluid_ports/tier3"
            }).key("L", {
                tag: "mm:fluid_ports/tier3"
            })
        })

    //中子充能仪(低级)
    event.create("mm:neutronium_charger_lesser")
        .controllerId("mm:neutronium_charger_lesser")
        .name("中子充能仪(低级)")
        .layout(a => {
            a.layer([
                " D ",
                " E ",
            ]).layer([
                "   ",
                "ACB",
            ]).key("A", {
                tag: "mm:fluid_ports/tier1"
            }).key("B", {
                tag: "mm:fluid_ports/tier1"
            }).key("D", {
                block: "mekanismgenerators:advanced_solar_generator"
            }).key("E", {
                tag: "mm:energy_ports/tier3"
            })
        })

    //中子充能仪(普通)
    event.create("mm:neutronium_charger_medium")
        .controllerId("mm:neutronium_charger_medium")
        .name("中子充能仪(普通)")
        .layout(a => {
            a.layer([
                " D ",
                " E ",
            ]).layer([
                "   ",
                "ACB",
            ]).key("A", {
                tag: "mm:fluid_ports/tier1"
            }).key("B", {
                tag: "mm:fluid_ports/tier1"
            }).key("D", {
                block: "mekanismgenerators:advanced_solar_generator"
            }).key("E", {
                tag: "mm:energy_ports/tier4"
            })
        })

    //中子充能仪(高级)
    event.create("mm:neutronium_charger_advanced")
        .controllerId("mm:neutronium_charger_advanced")
        .name("中子充能仪(高级)")
        .layout(a => {
            a.layer([
                " D ",
                " E ",
            ]).layer([
                "   ",
                "ACB",
            ]).key("A", {
                tag: "mm:fluid_ports/tier1"
            }).key("B", {
                tag: "mm:fluid_ports/tier1"
            }).key("D", {
                block: "mekanismgenerators:advanced_solar_generator"
            }).key("E", {
                tag: "mm:energy_ports/tier5"
            })
        })

    //巨型胃囊
    event.create("mm:stomach")
        .controllerId("mm:stomach_controller")
        .name("巨型胃囊")
        .layout(a => {
            a.layer([
            "   A   ",
            "  AAA ",
            " ABABA ",
            "AAAAAAA",
            " ABABA ",
            "  AAA  ",
            "   A   ",
            ]).layer([
              "  ABA  ",
              " A   A ",
              "A     A",
              "B     B",
              "A     A",
              " A   A ",
              "  ABA  ",
            ]).layer([
               " ABBBA ",
               "A     A",
               "B     B",
               "B     B",
               "B     B",
               "A     A",
               " ABBBA ",
            ]).layer([
               "ABBBBBA",
               "B     B",
               "B     B",
               "B     B",
               "B     B",
               "B     B",
               "ABBCBBA",
            ]).layer([
                " ABBBA ",
                "A     A",
                "D     F",
                "B     B",
                "E     G",
                "A     A",
                " ABHBA ",
            ]).layer([
                "  ABA  ",
                " A   A ",
                "A     A",
                "B     B",
                "A     A",
                " A   A ",
                "  ABA  ",
            ]).layer([
               "   A   ",
               "  AAA ",
               " ABABA ",
               "AAAAAAA",
               " ABABA ",
               "  AAA ",
               "   A   ",
            ]).key("A", {
                block: 'biomancy:flesh_pillar',
            }).key("B", {
                block: 'biomancy:impermeable_membrane',
            }).key("C", {
                block: "mm:stomach_controller",
            }).key("D", {
                port: "mm:stomach_item_port",
                input:true
            }).key("E", {
                port: "mm:stomach_item_port",
                input:false
            }).key("F", {
                port: "mm:stomach_fluid_port",
                input:true
            }).key("G", {
                port: "mm:stomach_fluid_port",
                input:false
            }).key("H", {
                port: "mm:stomach_energy_port",
                input:true
            })
        })

    //反应堆中子活化器
    event.create("mm:fisson_neutron_activator")
        .controllerId("mm:fisson_neutron_activator")
        .name("反应堆中子活化器")
        .layout(a => {
            a.layer([
                "  GGG  ",
                "  GGG  ",
                "  GGG  ",
                "  GGG  ",
                "  GGG  "
            ]).layer([
                " BAGAB ",
                " B   B ",
                " B D B ",
                " B   B ",
                " BAGAB "
            ]).layer([
                "GAGGGAG",
                "G     G",
                "G     G",
                "G     G",
                "GAGGGAG"
            ]).layer([
                "GGGGGGG",
                "G     G",
                "GD I DG",
                "G     G",
                "GGGCGGG"
            ]).layer([
                "GAGGGAG",
                "G     G",
                "G     G",
                "G     G",
                "GAGGGAG"
            ]).layer([
                " BAGAB ",
                " B   B ",
                " B D B ",
                " B   B ",
                " BAGAB "
            ]).layer([
                "  GGG  ",
                "  GGG  ",
                "  GGG  ",
                "  GGG  ",
                "  GGG  "
            ]).key("A", {
                block: "mekanism:sps_casing"
            }).key("B", {
                block: "mekanismgenerators:reactor_glass"
            }).key("D", {
                block: "kubejs:protonium_block"
            }).key("G", {
                tag: "mm:is_neutronactivator_casing"
            }).key("I", {
                block: "kubejs:electronium_block"
            })
        })
    //一体化集成燃油发动机
    event.create("mm:integrated_fuel_engine")
        .controllerId("mm:integrated_fuel_engine")
        .name("一体化集成燃油发动机")
        .layout(a => {
            a.layer([
                "BBBBBBBBBBBB",
                "B     B    B",
                "B     B    B",
                "B     B    B",
                "B     B    B",
                "B     B    B",
                "BBBBBBBBBBBB"
            ]).layer([
                "B     B    B",
                "       BAAB ",
                "  AAAA AAAA ",
                "  AAAA AAAA ",
                "  AAAA AAAA ",
                "       BAAB ",
                "B     B    B"
            ]).layer([
                "B     B    B",
                "  AAAA AEEA ",
                "AAAAAAAADDF ",
                "AA    AADDF ",
                "AAAAAAAADDF ",
                "  AAAA AEEA ",
                "B     B    B"
            ]).layer([
                "B     B    B",
                "BBAAAABAEEA ",
                "AA    AADDF ",
                "HGGGGGGADDF ",
                "AA    AADDF ",
                "BBAAAABAEEA ",
                "B     B    B"
            ]).layer([
                "B     B    B",
                "BBAAAABAEEA ",
                "AAAAAAAADDF ",
                "AA    AADDF ",
                "AAAAAAAADDF ",
                "BBAAAABAEEA ",
                "B     B    B"
            ]).layer([
                "BBBBBBB    B",
                "BBBBBBBBFFB ",
                "BBAAAABAAAA ",
                "BBAAAABAAAA ",
                "BBAAAABAAAA ",
                "BBBBBBBBCFB ",
                "BBBBBBB    B"
            ]).layer([
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA",
                "AAAAAAAAAAAA"
            ]).key("A", {
                block: "immersiveengineering:sheetmetal_steel"
            }).key("B", {
                block: "immersiveengineering:steel_scaffolding_standard"
            }).key("D", {
                block: "minecraft:magma_block"
            }).key("E", {
                block: "minecraft:orange_stained_glass_pane"
            }).key("F", {
                tag: "mm:integrated_fuel_engine_matter"
            }).key("G", {
                block: "minecraft:end_rod"
            }).key("H", {
                tag: "mm:integrated_fuel_engine_energy"
            })
        })
})