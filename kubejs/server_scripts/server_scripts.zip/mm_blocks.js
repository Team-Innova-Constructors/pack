ServerEvents.recipes(event => {
  //过载能量注入器
  event.shaped(Item.of('mm:overload_infuser',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'powah:energizing_rod_nitro',
    C: 'ae2:charger'
  })

  //中子充能仪
  event.shaped(Item.of('mm:neutronium_charger_lesser',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'powah:energizing_rod_nitro',
    C: 'thermal:charge_bench'
  })
  event.shaped(Item.of('mm:neutronium_charger_advanced',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:neutronium_charger_medium'
  })

  //钢接口
  event.shaped(Item.of('mm:steel_item_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: '#forge:chests/wooden',
    C: 'minecraft:barrel'
  })
  event.shaped(Item.of('mm:steel_item_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'minecraft:hopper',
    C: 'minecraft:barrel'
  })
  event.shaped(Item.of('mm:steel_energy_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'thermal:rf_coil',
    C: 'thermal:energy_cell_frame'
  })
  event.shaped(Item.of('mm:steel_energy_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'thermal:redstone_servo',
    C: 'thermal:energy_cell_frame'
  })
  event.shaped(Item.of('mm:steel_fluid_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'thermal:redstone_servo',
    C: 'immersiveengineering:fluid_sorter'
  })
  event.shaped(Item.of('mm:steel_fluid_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'thermal:redstone_servo',
    C: 'thermal:fluid_cell'
  })
  event.shaped(Item.of('mm:steel_kinetic_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'create:large_cogwheel',
    C: 'create:vertical_gearbox'
  })
  event.shaped(Item.of('mm:steel_kinetic_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: '#forge:ingots/steel',
    B: 'create:large_cogwheel',
    C: 'create:gearbox'
  })

  //硬铅接口
  event.shaped(Item.of('mm:hardlead_item_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_item_port_output'
  })
  event.shaped(Item.of('mm:hardlead_item_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_item_port_input'
  })
  event.shaped(Item.of('mm:hardlead_energy_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_energy_port_input'
  })
  event.shaped(Item.of('mm:hardlead_energy_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_energy_port_output'
  })
  event.shaped(Item.of('mm:hardlead_fluid_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_fluid_port_input'
  })
  event.shaped(Item.of('mm:hardlead_fluid_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'mekanism:advanced_control_circuit',
    C: 'mm:steel_fluid_port_output'
  })
  event.shaped(Item.of('mm:hardlead_air_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'pneumaticcraft:pressure_tube',
    C: 'pneumaticcraft:pressure_chamber_valve'
  })
  event.shaped(Item.of('mm:hardlead_air_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'pneumaticcraft:pressure_tube',
    C: 'pneumaticcraft:pressure_chamber_wall'
  })
  event.shaped(Item.of('mm:hardlead_kinetic_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'create:precision_mechanism',
    C: 'mm:steel_kinetic_port_input'
  })
  event.shaped(Item.of('mm:hardlead_kinetic_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'kubejs:compressed_hardlead',
    B: 'create:precision_mechanism',
    C: 'mm:steel_kinetic_port_output'
  })

  //超致密接口
  event.shaped(Item.of('mm:ultra_dense_item_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_item_port_output'
  })
  event.shaped(Item.of('mm:ultra_dense_item_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_item_port_input'
  })
  event.shaped(Item.of('mm:ultra_dense_energy_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_energy_port_input'
  })
  event.shaped(Item.of('mm:ultra_dense_energy_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_energy_port_output'
  })
  event.shaped(Item.of('mm:ultra_dense_fluid_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_fluid_port_input'
  })
  event.shaped(Item.of('mm:ultra_dense_fluid_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_fluid_port_output'
  })
  event.shaped(Item.of('mm:ultra_dense_air_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_air_port_output'
  })
  event.shaped(Item.of('mm:ultra_dense_air_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_air_port_input'
  })
  event.shaped(Item.of('mm:ultra_dense_kinetic_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_kinetic_port_input'
  })
  event.shaped(Item.of('mm:ultra_dense_kinetic_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekaevolution:absolute_control_circuit',
    C: 'mm:hardlead_kinetic_port_output'
  })
  event.shaped(Item.of('mm:ultra_dense_gas_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:basic_control_circuit',
    C: 'mekanism:dynamic_valve'
  })
  event.shaped(Item.of('mm:ultra_dense_gas_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:basic_control_circuit',
    C: 'mekanism:dynamic_tank'
  })
  event.shaped(Item.of('mm:ultra_dense_infuse_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:enriched_redstone',
    C: 'mekanism:dynamic_valve'
  })
  event.shaped(Item.of('mm:ultra_dense_infuse_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:enriched_redstone',
    C: 'mekanism:dynamic_tank'
  })
  event.shaped(Item.of('mm:ultra_dense_slurry_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:alloy_infused',
    C: 'mekanism:dynamic_valve'
  })
  event.shaped(Item.of('mm:ultra_dense_slurry_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:ultra_dense',
    B: 'mekanism:alloy_infused',
    C: 'mekanism:dynamic_tank'
  })

  //质子接口
  event.shaped(Item.of('mm:protonium_item_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_item_port_output'
  })
  event.shaped(Item.of('mm:protonium_item_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_item_port_input'
  })
  event.shaped(Item.of('mm:protonium_energy_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_energy_port_input'
  })
  event.shaped(Item.of('mm:protonium_energy_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_energy_port_output'
  })
  event.shaped(Item.of('mm:protonium_fluid_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_fluid_port_input'
  })
  event.shaped(Item.of('mm:protonium_fluid_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_fluid_port_output'
  })
  event.shaped(Item.of('mm:protonium_air_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_air_port_output'
  })
  event.shaped(Item.of('mm:protonium_air_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_air_port_input'
  })
  event.shaped(Item.of('mm:protonium_kinetic_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_kinetic_port_input'
  })
  event.shaped(Item.of('mm:protonium_kinetic_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekaevolution:cosmic_control_circuit',
    C: 'mm:overcharged_ultra_dense_kinetic_port_output'
  })
  event.shaped(Item.of('mm:protonium_gas_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:basic_control_circuit',
    C: 'mm:overcharged_ultra_dense_gas_port_input'
  })
  event.shaped(Item.of('mm:protonium_gas_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:basic_control_circuit',
    C: 'mm:overcharged_ultra_dense_gas_port_output'
  })
  event.shaped(Item.of('mm:protonium_infuse_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:enriched_redstone',
    C: 'mm:overcharged_ultra_dense_infuse_port_input'
  })
  event.shaped(Item.of('mm:protonium_infuse_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:enriched_redstone',
    C: 'mm:overcharged_ultra_dense_infuse_port_output'
  })
  event.shaped(Item.of('mm:protonium_slurry_port_input',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:alloy_infused',
    C: 'mm:overcharged_ultra_dense_slurry_port_input'
  })
  event.shaped(Item.of('mm:protonium_slurry_port_output',1), [
    'AAA',
    'BCB',
    'AAA'
  ],
  {
    A: 'etshtinker:protonium',
    B: 'mekanism:alloy_infused',
    C: 'mm:overcharged_ultra_dense_slurry_port_output'
  })
  
})