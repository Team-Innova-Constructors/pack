ServerEvents.recipes(event => {
    event.replaceInput({mod:'powah',output:'powah:crystal_nitro'}, '#forge:storage_blocks/redstone','jaopca:storage_blocks.tungsten')
})