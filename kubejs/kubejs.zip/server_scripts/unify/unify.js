ServerEvents.recipes(event => {
    event.replaceOutput({output:'#forge:ingots/tin',not:{output:'thermal:tin_ingot'}}, '#forge:ingots/tin','thermal:tin_ingot')
    event.replaceOutput({output:'#forge:nuggets/tin',not:{output:'thermal:tin_nugget'}}, '#forge:nuggets/tin','thermal:tin_nugget')
    event.replaceOutput({output:'#forge:dusts/tin',not:{output:'thermal:tin_dust'}}, '#forge:dusts/tin','thermal:tin_dust')
    event.replaceOutput({output:'#forge:plates/tin',not:{output:'thermal:tin_plate'}}, '#forge:plates/tin','thermal:tin_plate')
    event.replaceOutput({output:'#forge:storage_blocks/tin',not:{output:'thermal:tin_block'}}, '#forge:storage_blocks/tin','thermal:tin_block')
    
    event.replaceOutput({output:'#forge:ingots/lead',not:{output:'thermal:lead_ingot'}}, '#forge:ingots/lead','thermal:lead_ingot')
    event.replaceOutput({output:'#forge:nuggets/lead',not:{output:'thermal:lead_nugget'}}, '#forge:nuggets/lead','thermal:lead_nugget')
    event.replaceOutput({output:'#forge:dusts/lead',not:{output:'thermal:lead_dust'}}, '#forge:dusts/lead','thermal:lead_dust')
    event.replaceOutput({output:'#forge:plates/lead',not:{output:'thermal:lead_plate'}}, '#forge:plates/lead','thermal:lead_plate')
    event.replaceOutput({output:'#forge:storage_blocks/lead',not:{output:'thermal:lead_block'}}, '#forge:storage_blocks/lead','thermal:lead_block')

    event.replaceOutput({output:'#forge:ingots/silver',not:{output:'thermal:silver_ingot'}}, '#forge:ingots/silver','thermal:silver_ingot')
    event.replaceOutput({output:'#forge:nuggets/silver',not:{output:'thermal:silver_nugget'}}, '#forge:nuggets/silver','thermal:silver_nugget')
    event.replaceOutput({output:'#forge:dusts/silver',not:{output:'thermal:silver_dust'}}, '#forge:dusts/silver','thermal:silver_dust')
    event.replaceOutput({output:'#forge:plates/silver',not:{output:'thermal:silver_plate'}}, '#forge:plates/silver','thermal:silver_plate')
    event.replaceOutput({output:'#forge:storage_blocks/silver',not:{output:'thermal:silver_block'}}, '#forge:storage_blocks/silver','thermal:silver_block')

    event.replaceOutput({output:'#forge:ingots/nickel',not:{output:'thermal:nickel_ingot'}}, '#forge:ingots/nickel','thermal:nickel_ingot')
    event.replaceOutput({output:'#forge:nuggets/nickel',not:{output:'thermal:nickel_nugget'}}, '#forge:nuggets/nickel','thermal:nickel_nugget')
    event.replaceOutput({output:'#forge:dusts/nickel',not:{output:'thermal:nickel_dust'}}, '#forge:dusts/nickel','thermal:nickel_dust')
    event.replaceOutput({output:'#forge:plates/nickel',not:{output:'thermal:nickel_plate'}}, '#forge:plates/nickel','thermal:nickel_plate')
    event.replaceOutput({output:'#forge:storage_blocks/nickel',not:{output:'thermal:nickel_block'}}, '#forge:storage_blocks/nickel','thermal:nickel_block')

    event.replaceOutput({output:'#forge:ingots/bronze',not:{output:'thermal:bronze_ingot'}}, '#forge:ingots/bronze','thermal:bronze_ingot')
    event.replaceOutput({output:'#forge:nuggets/bronze',not:{output:'thermal:bronze_nugget'}}, '#forge:nuggets/bronze','thermal:bronze_nugget')
    event.replaceOutput({output:'#forge:dusts/bronze',not:{output:'thermal:bronze_dust'}}, '#forge:dusts/bronze','thermal:bronze_dust')
    event.replaceOutput({output:'#forge:plates/bronze',not:{output:'thermal:bronze_plate'}}, '#forge:plates/bronze','thermal:bronze_plate')
    event.replaceOutput({output:'#forge:storage_blocks/bronze',not:{output:'thermal:bronze_block'}}, '#forge:storage_blocks/bronze','thermal:bronze_block')

    event.replaceOutput({output:'#forge:ingots/electrum',not:{output:'thermal:electrum_ingot'}}, '#forge:ingots/electrum','thermal:electrum_ingot')
    event.replaceOutput({output:'#forge:nuggets/electrum',not:{output:'thermal:electrum_nugget'}}, '#forge:nuggets/electrum','thermal:electrum_nugget')
    event.replaceOutput({output:'#forge:dusts/electrum',not:{output:'thermal:electrum_dust'}}, '#forge:dusts/electrum','thermal:electrum_dust')
    event.replaceOutput({output:'#forge:plates/electrum',not:{output:'thermal:electrum_plate'}}, '#forge:plates/electrum','thermal:electrum_plate')
    event.replaceOutput({output:'#forge:storage_blocks/electrum',not:{output:'thermal:electrum_block'}}, '#forge:storage_blocks/electrum','thermal:electrum_block')

    event.replaceOutput({output:'#forge:ingots/constantan',not:{output:'thermal:constantan_ingot'}}, '#forge:ingots/constantan','thermal:constantan_ingot')
    event.replaceOutput({output:'#forge:nuggets/constantan',not:{output:'thermal:constantan_nugget'}}, '#forge:nuggets/constantan','thermal:constantan_nugget')
    event.replaceOutput({output:'#forge:dusts/constantan',not:{output:'thermal:constantan_dust'}}, '#forge:dusts/constantan','thermal:constantan_dust')
    event.replaceOutput({output:'#forge:plates/constantan',not:{output:'thermal:constantan_plate'}}, '#forge:plates/constantan','thermal:constantan_plate')
    event.replaceOutput({output:'#forge:storage_blocks/constantan',not:{output:'thermal:constantan_block'}}, '#forge:storage_blocks/constantan','thermal:constantan_block')

    event.replaceOutput({output:'#forge:ingots/steel',not:{output:'thermal:steel_ingot'}}, '#forge:ingots/steel','thermal:steel_ingot')
    event.replaceOutput({output:'#forge:nuggets/steel',not:{output:'thermal:steel_nugget'}}, '#forge:nuggets/steel','thermal:steel_nugget')
    event.replaceOutput({output:'#forge:dusts/steel',not:{output:'thermal:steel_dust'}}, '#forge:dusts/steel','thermal:steel_dust')
    event.replaceOutput({output:'#forge:plates/steel',not:{output:'thermal:steel_plate'}}, '#forge:plates/steel','thermal:steel_plate')
    event.replaceOutput({output:'#forge:storage_blocks/steel',not:{output:'thermal:steel_block'}}, '#forge:storage_blocks/steel','thermal:steel_block')

    event.replaceOutput({output:'#forge:ingots/aluminum',not:{output:'immersiveengineering:ingot_aluminum'}}, '#forge:ingots/aluminum','immersiveengineering:steel_ingot')
    event.replaceOutput({output:'#forge:nuggets/aluminum',not:{output:'immersiveengineering:nugget_aluminum'}}, '#forge:nuggets/aluminum','immersiveengineering:nugget_aluminum')
    event.replaceOutput({output:'#forge:dusts/aluminum',not:{output:'immersiveengineering:dust_aluminum'}}, '#forge:dusts/aluminum','immersiveengineering:dust_aluminum')
    event.replaceOutput({output:'#forge:plates/aluminum',not:{output:'immersiveengineering:plate_aluminum'}}, '#forge:plates/aluminum','immersiveengineering:plate_aluminum')
    event.replaceOutput({output:'#forge:storage_blocks/aluminum',not:{output:'immersiveengineering:block_aluminum'}}, '#forge:storage_blocks/aluminum','immersiveengineering:block_aluminum')

    event.replaceOutput({output:'#forge:ingots/uranium',not:{output:'mekanism:ingot_uranium'}}, '#forge:ingots/uranium','mekanism:steel_ingot')
    event.replaceOutput({output:'#forge:nuggets/uranium',not:{output:'mekanism:nugget_uranium'}}, '#forge:nuggets/uranium','mekanism:nugget_uranium')
    event.replaceOutput({output:'#forge:dusts/uranium',not:{output:'mekanism:dust_uranium'}}, '#forge:dusts/uranium','mekanism:dust_uranium')
    event.replaceOutput({output:'#forge:storage_blocks/uranium',not:{output:'mekanism:block_uranium'}}, '#forge:storage_blocks/uranium','mekanism:block_uranium')

    event.replaceOutput({output:'#forge:ingots/rose_gold',not:{output:'tconstruct:rose_gold_ingot'}}, '#forge:ingots/rose_gold','tconstruct:rose_gold_ingot')
    event.replaceOutput({output:'#forge:storage_blocks/rose_gold',not:{output:'tconstruct:rose_gold_block'}}, '#forge:storage_blocks/rose_gold','tconstruct:rose_gold_block')

    event.replaceOutput({output:'#forge:dusts/iron',not:{output:'thermal:iron_dust'}}, '#forge:dusts/iron','thermal:iron_dust')

    event.replaceOutput({output:'#forge:dusts/gold',not:{output:'thermal:gold_dust'}}, '#forge:dusts/gold','thermal:gold_dust')

    event.replaceOutput({output:'#forge:dusts/copper',not:{output:'thermal:copper_dust'}}, '#forge:dusts/copper','thermal:copper_dust')

    event.replaceOutput({output:'#forge:dusts/lapis',not:{output:'thermal:lapis_dust'}}, '#forge:dusts/lapis','thermal:lapis_dust')
    
    event.replaceOutput({output:'#forge:dusts/netherite',not:{output:'thermal:netherite_dust'}}, '#forge:dusts/netherite','thermal:netherite_dust')

    event.replaceOutput({output:'#forge:dusts/diamond',not:{output:'thermal:diamond_dust'}}, '#forge:dusts/diamond','thermal:diamond_dust')
    
    event.replaceOutput({output:'#forge:dusts/emerald',not:{output:'thermal:emerald_dust'}}, '#forge:dusts/emerald','thermal:emerald_dust')

    event.replaceOutput({output:'#forge:dusts/quartz',not:{output:'thermal:quartz_dust'}}, '#forge:dusts/quartz','thermal:quartz_dust')

    event.replaceOutput({output:'#forge:nuggets/copper',not:{output:'tconstruct:copper_nugget'}}, '#forge:nuggets/copper','tconstruct:copper_nugget')
})