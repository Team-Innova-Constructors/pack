MMEvents.registerControllers(event => {
    event.create("stomach_controller")
        .name("stomach_controller")
        .type( "mm:machine")

    event.create("neutronium_charger_lesser")
        .name("中子充能仪(低级)")
        .type( "mm:machine")
    event.create("neutronium_charger_medium")
        .name("中子充能仪(普通)")
        .type( "mm:machine")
    event.create("neutronium_charger_advanced")
        .name("中子充能仪(高级)")
        .type( "mm:machine")

    event.create("overload_infuser")
        .name("过载能量注入器")
        .type( "mm:machine")

    event.create("fisson_neutron_activator")
        .name("反应堆中子活化器")
        .type( "mm:machine")

    event.create("integrated_fuel_engine")
        .name("一体化集成燃油发动机")
        .type( "mm:machine")
});