StartupEvents.registry('item', event => {
    event.create('kubejs:incomplete_mekasuit','create:sequenced_assembly')
})