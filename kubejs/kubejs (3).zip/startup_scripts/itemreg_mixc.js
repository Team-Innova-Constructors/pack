StartupEvents.registry("item",event=>{
    event.create("ultra_dense_nugget","basic")
    event.create("overchargedultradense","basic")
    event.create("protonium_nugget","basic")
    event.create("gas_hydrate","basic")
    event.create("graphene","basic")
})