StartupEvents.registry("item",event=>{
    event.create("compressed_hardlead","basic")
    event.create("zirconium_alloy","basic")
    event.create("compressed_activated_chroma_plate","basic")
})